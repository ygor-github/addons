# -*- coding: utf-8 -*-
from . import mail_message
from . import res_config_settings